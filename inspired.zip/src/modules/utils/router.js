import Navigo from 'navigo';

export const router = new Navigo('/', { hash: true });
